package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;


public class CreateGuest extends AppCompatActivity {

    private DataInputStream inputStream;
    private DataOutputStream outputStream;

    private LogIn logIn = new LogIn();

    private Button back, save;

    private EditText user, password, name, surname, mail,
            docType, numDoc, street, phone, gender, role;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_guest);

        getSupportActionBar().hide();

        user = findViewById(R.id.user);
        password = findViewById(R.id.password);
        name = findViewById(R.id.name);
        surname = findViewById(R.id.phone);
        mail = findViewById(R.id.mail);
        docType = findViewById(R.id.docType);
        numDoc = findViewById(R.id.numdoc);
        street = findViewById(R.id.street);
        phone = findViewById(R.id.phone);
        gender = findViewById(R.id.gender);
        role = findViewById(R.id.role);

        back = findViewById(R.id.back);
        save = findViewById(R.id.save);


        back.setOnClickListener(v -> startActivity(new Intent(this, Guests.class)));

        save.setOnClickListener(v -> {

            new Task().execute();
            Toast.makeText(this, "SAVED", Toast.LENGTH_SHORT).show();

        });

    }


    class Task extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String ... strings) {

            try {

                Socket socket = new Socket(logIn.getIp(), logIn.getPort());

                inputStream = new DataInputStream(socket.getInputStream());
                outputStream = new DataOutputStream(socket.getOutputStream());

                outputStream.writeUTF(user.getText().toString());
                outputStream.writeUTF(password.getText().toString());
                outputStream.writeUTF(name.getText().toString());
                outputStream.writeUTF(surname.getText().toString());
                outputStream.writeUTF(mail.getText().toString());
                outputStream.writeUTF(docType.getText().toString());
                outputStream.writeUTF(numDoc.getText().toString());
                outputStream.writeUTF(street.getText().toString());
                outputStream.writeUTF(phone.getText().toString());
                outputStream.writeUTF(gender.getText().toString());
                outputStream.writeUTF(role.getText().toString());

                outputStream.writeInt(2);
                outputStream.writeInt(1);
                outputStream.writeInt(1);

            }

            catch (IOException e) {
                e.printStackTrace();
            }

            return strings[0];

        }

    }

}