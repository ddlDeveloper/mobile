package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;


public class AdminMenu extends AppCompatActivity {

    Button reservation, services, users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_menu);

        getSupportActionBar().hide();

        reservation = findViewById(R.id.reservation);
        services = findViewById(R.id.services);
        users = findViewById(R.id.users);

//        reservation.setOnClickListener(v -> Toast.makeText(this, "DBG", Toast.LENGTH_SHORT).show());
//        discounts.setOnClickListener(v -> Toast.makeText(this, "DBGG", Toast.LENGTH_SHORT).show());
//        services.setOnClickListener(v -> Toast.makeText(this, "DBGGG", Toast.LENGTH_SHORT).show());
//        users.setOnClickListener(v -> Toast.makeText(this, "DBGGGGG", Toast.LENGTH_SHORT).show());

    }

}