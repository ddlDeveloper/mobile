package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;


public class Guests extends AppCompatActivity {

    private Button create, alter, remove, back, list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guests);

        getSupportActionBar().hide();

        create = findViewById(R.id.create);
        alter = findViewById(R.id.update);
        remove = findViewById(R.id.remove);
        list = findViewById(R.id.read);
        back = findViewById(R.id.back);

        list.setOnClickListener(v -> startActivity(new Intent(this, ReadGuests.class)));
        create.setOnClickListener(v -> startActivity(new Intent(this, CreateGuest.class)));
        alter.setOnClickListener(v -> startActivity(new Intent(this, UpdateGuest.class)));
        remove.setOnClickListener(v -> startActivity(new Intent(this, RemoveGuest.class)));
        back.setOnClickListener(v -> startActivity(new Intent(this, AdminMenu.class)));

    }

}