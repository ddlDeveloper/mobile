package ioc.ddl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RemoveService extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_service);
    }
}