package ioc.ddl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class CreateService extends AppCompatActivity {

    private Spinner spin;

    private String[] services = {"SPA", "GYM", "THEATRE", "HAIRDRESSER"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_service);

        getSupportActionBar().hide();


        spin = findViewById(R.id.spin);


//        spin.setOnClickListener(v -> {
//
//            Toast.makeText(this, "***********", Toast.LENGTH_SHORT).show();
//
//            ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, services);
//
//            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//
//            spin.setAdapter(adapter);
//
//    }

    }
}