package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;


public class RemoveReservation extends AppCompatActivity {

    private boolean ok;

    private EditText userPhone;

    private LogIn logIn = new LogIn();

    private DataOutputStream outputStream;

    private Button back, remove;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_reservation);

        getSupportActionBar().hide();

        back = findViewById(R.id.back);
        remove = findViewById(R.id.remove);
        userPhone = findViewById(R.id.userPhone);


        back.setOnClickListener(v -> startActivity(new Intent(this, Reservations.class)));

        remove.setOnClickListener(v -> {

            checkUserPhone(userPhone.getText().toString());

            if (ok) {
                new RemoveReservation.Tasca().execute();
                Toast.makeText(this, "REMOVED", Toast.LENGTH_LONG).show();
            }


        });


    }

    class Tasca extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String ... strings) {

            try {

                outputStream.writeInt(7);
                outputStream.writeInt(2);
                outputStream.writeInt(1);

                Socket socket = new Socket(logIn.getIp(), logIn.getPort());

                outputStream = new DataOutputStream(socket.getOutputStream());

                outputStream.writeUTF(userPhone.getText().toString());

            }

            catch (IOException e) {

                e.printStackTrace();
            }

            return strings[0];

        }

    }

    public boolean checkUserPhone(String phone) {

        if (phone.isEmpty()) {
            Toast.makeText(this, "FILL PHONE GAP", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else {
            ok = true;
        }

        return ok;

    }

}