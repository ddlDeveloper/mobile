package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;


public class DeleteReservation extends AppCompatActivity {

    private static boolean ok;

    private EditText userPhone;

    private LogIn logIn = new LogIn();

    private DataOutputStream outputStream;

    private Button back, remove;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_reservation);

        getSupportActionBar().hide();

        back = findViewById(R.id.back);
        remove = findViewById(R.id.remove);
        userPhone = findViewById(R.id.userPhone);


        back.setOnClickListener(v -> startActivity(new Intent(this, Reservations.class)));

        remove.setOnClickListener(v -> {

            checkGuestPhone(userPhone.getText().toString());

            if (ok) {
                new DeleteReservation.Tasca().execute();
                Toast.makeText(this, "REMOVED", Toast.LENGTH_LONG).show();
            }


        });


    }

    class Tasca extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String ... strings) {

            try {

                outputStream.writeInt(7);
                outputStream.writeInt(2);
                outputStream.writeInt(1);

                Socket socket = new Socket(logIn.getIp(), logIn.getPort());

                outputStream = new DataOutputStream(socket.getOutputStream());

                outputStream.writeUTF(userPhone.getText().toString());

            }

            catch (IOException e) {

                e.printStackTrace();
            }

            return strings[0];

        }

    }

    public static boolean checkGuestPhone(String phone) {

        char[] phoneNumber = phone.toCharArray();

        for (int i = 0; i < phoneNumber.length; i++) {

            if (Character.isLetter(phone.charAt(i))) {
                ok = false;
                System.out.println ("COINTAINS LETTERS");
            }
        }

        if (phone.isEmpty()) {
            System.out.println ("FILL PHONE GAP");
            ok = false;
        }

        else {
            ok = true;
            System.out.println ("ok");
        }

        return ok;

    }


}