package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import ioc.ddl.utils.SystemUtils;


public class LogIn extends AppCompatActivity {

    private int port = 8000;
    private String ip = "10.0.2.2";

    public int getPort() {

        return port;
    }
    public String getIp() {

        return ip;
    }

    private DataInputStream inputStream;
    private DataOutputStream outputStream;

    public DataInputStream getInputStream() {

        return inputStream;
    }
    public DataOutputStream getOutputStream() {

        return outputStream;
    }

    private Button signUpBut, logIn;

    private EditText passwd, user;
    public EditText getPasswd() {

        return passwd;
    }
    public EditText getUser() {

        return user;
    }

    final String KEY = "abecedari69@";

    private int rol;
    public int getRol() {

        return rol;
    }

    private boolean usrValid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        user = findViewById(R.id.user);
        passwd = findViewById(R.id.passwd);

        logIn = findViewById(R.id.loginBtn);
        signUpBut = findViewById(R.id.signUpBtn);

        getSupportActionBar().hide();

        signUpBut.setOnClickListener(v -> startActivity(new Intent(this, SignUp.class)));

        logIn.setOnClickListener(v -> {

            validaUsuari(user.getText().toString(), passwd.getText().toString());

            if (usrValid) {

                new Tasca().execute("");

                Toast.makeText(this, String.valueOf(rol), Toast.LENGTH_SHORT).show();
                Log.i("ROL ->", String.valueOf(rol));

                if (rol == 0) startActivity(new Intent(this, AdminMenu.class));
                if (passwd.getText().toString().equals("password2")) startActivity(new Intent(this, NoAdminMenu.class));

            }

        });



    }


    public boolean validaUsuari(String usr, String pass) {

        if (usr.isEmpty() && pass.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Introdueix usuari i contrasenya", Toast.LENGTH_LONG).show();
            usrValid = false;

        }

        else if (usr.isEmpty()) {
            Toast.makeText(this, "Introdueix un usuari", Toast.LENGTH_SHORT).show();
            usrValid = false;

        }

        else if (pass.isEmpty()) {
            Toast.makeText(this, "Introdueix una contrasenya", Toast.LENGTH_SHORT).show();
            usrValid = false;

        }

        else {
            usrValid = true;

        }

        return usrValid;

    }


    class Tasca extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String ... strings) {

            try {

                Socket socket = new Socket(ip, port);

                inputStream = new DataInputStream(socket.getInputStream());
                outputStream = new DataOutputStream(socket.getOutputStream());

                String[] claus_ps = SystemUtils.clauPublicaClient().split(",");
                outputStream.writeUTF(String.valueOf(claus_ps[0]));

                BigInteger shared_secret = SystemUtils.calculClauCompartida(inputStream.readUTF(), claus_ps[1]);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    outputStream.writeUTF(SystemUtils.encryptedText(
                                    user.getText().toString()
                                            + ","
                                            + SystemUtils.convertirSHA256(
                                            passwd.getText().toString()), shared_secret.toByteArray()
                            )

                    );

                }

                outputStream.writeInt(1);

                rol = inputStream.readInt();

            }

            catch (IOException e) {
                e.printStackTrace();
            }


            return strings[0];

        }

    }

}





