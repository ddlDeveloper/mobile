package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Calendar;


public class CreateReservation extends AppCompatActivity {

    private Button back, save;

    private DataInputStream dataInputStream;
    private DataOutputStream dataOutputStream;

    private EditText initReservation, endReservation;

    private LogIn logIn = new LogIn();

    private int port = logIn.getPort();
    private String ip = logIn.getIp();

    private final Calendar calendar = Calendar.getInstance();

    private int year = calendar.get (Calendar.YEAR);
    private int month = calendar.get (Calendar.MONTH);
    private int day = calendar.get (Calendar.DAY_OF_MONTH);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_reservation);

        initReservation = findViewById(R.id.initReservation);
        endReservation = findViewById(R.id.endReservation);

        back = findViewById(R.id.back);
        save = findViewById(R.id.save);


        getSupportActionBar().hide();

        initReservation.setOnClickListener(v -> {

            DatePickerDialog datePickerDialog = new DatePickerDialog (
                    CreateReservation.this,

                    (view, year1, monthOfYear, dayOfMonth) ->
                            initReservation.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year1), year, month, day
            );

            datePickerDialog.show();

        });

        endReservation.setOnClickListener(v -> {

            DatePickerDialog datePickerDialog = new DatePickerDialog (
                    CreateReservation.this,

                    (view, year1, monthOfYear, dayOfMonth) ->
                            endReservation.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year1), year, month, day
            );

            datePickerDialog.show();

        });

        back.setOnClickListener(v -> startActivity(new Intent(this, Reservation.class)));

        save.setOnClickListener(v -> {

//            new CreateReservation.Tasca().execute();
            Toast.makeText(this, "SAVED", Toast.LENGTH_SHORT).show();


        });


    }

    class Tasca extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String ... strings) {

            try {

                Socket socket = new Socket(ip, port);

                dataInputStream = new DataInputStream(socket.getInputStream());
                dataOutputStream = new DataOutputStream(socket.getOutputStream());



                dataOutputStream.writeInt(1);

            }

            catch (IOException e) {
                e.printStackTrace();
            }

            return strings[0];

        }

    }


}