package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;


public class CreateService extends AppCompatActivity {

    private Spinner spinner;

    private Button save, back;

    private String[] services = {"SPA", "GYM", "THEATRE", "HAIRDRESSER", "SAUNA", "TENNIS", "BILLARDS", "TOUR"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_service);

        getSupportActionBar().hide();


        save = findViewById(R.id.save);
        back = findViewById(R.id.back);
        spinner = findViewById(R.id.spinner);

        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item, services);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);

        save.setOnClickListener(v -> {

            Toast.makeText(this, "SAVED", Toast.LENGTH_LONG).show();
            Toast.makeText(this, spinner.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();


        });

        back.setOnClickListener(v -> startActivity(new Intent(this, Services.class)));




    }


}