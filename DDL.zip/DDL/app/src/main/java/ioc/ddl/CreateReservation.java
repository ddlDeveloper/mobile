package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Calendar;


public class CreateReservation extends AppCompatActivity {

    private Button back, save;

    private DataInputStream inputStream;
    private DataOutputStream outputStream;

    private EditText initReservation, endReservation;

    private LogIn logIn = new LogIn();

    private final Calendar calendar = Calendar.getInstance();

    private int initYear = calendar.get (Calendar.YEAR);
    private int initMonth = calendar.get (Calendar.MONTH);
    private int initDay = calendar.get (Calendar.DAY_OF_MONTH);

    private int finalYear = calendar.get (Calendar.YEAR);
    private int finalMonth = calendar.get (Calendar.MONTH);
    private int finalDay = calendar.get (Calendar.DAY_OF_MONTH);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_reservation);

        getSupportActionBar().hide();

        initReservation = findViewById(R.id.initReservation);
        endReservation = findViewById(R.id.endReservation);

        back = findViewById(R.id.back);
        save = findViewById(R.id.save);


        initReservation.setOnClickListener(v -> {

            DatePickerDialog datePickerDialog = new DatePickerDialog (
                    CreateReservation.this,

                    (view, year1, monthOfYear, dayOfMonth) ->
                            initReservation.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year1),
                    initYear, initMonth, finalDay
            );

            datePickerDialog.show();


        });

        endReservation.setOnClickListener(v -> {

            DatePickerDialog datePickerDialog = new DatePickerDialog (
                    CreateReservation.this,

                    (view, year1, monthOfYear, dayOfMonth) ->
                            endReservation.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year1),
                    finalYear, finalMonth, initDay
            );

            datePickerDialog.show();

        });

        back.setOnClickListener(v -> startActivity(new Intent(this, Reservation.class)));

        save.setOnClickListener(v -> {

            new Task().execute("");
            Toast.makeText(this, "SAVED", Toast.LENGTH_LONG).show();


        });


    }


    class Task extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String ... strings) {

            try {

                Socket socket = new Socket(logIn.getIp(), logIn.getPort());

                inputStream = new DataInputStream(socket.getInputStream());
                outputStream = new DataOutputStream(socket.getOutputStream());

                outputStream.writeInt(3);
                outputStream.writeInt(1);
                outputStream.writeInt(1);

                // Initial Date
                outputStream.writeUTF(String.valueOf(initYear));
                outputStream.writeUTF(String.valueOf(initMonth));
                outputStream.writeUTF(String.valueOf(initDay));

                // Final Date
                outputStream.writeUTF(String.valueOf(finalYear));
                outputStream.writeUTF(String.valueOf(finalMonth));
                outputStream.writeUTF(String.valueOf(finalDay));

            }

            catch (IOException e) {

                e.printStackTrace();
            }

            return strings[0];

        }

    }


}