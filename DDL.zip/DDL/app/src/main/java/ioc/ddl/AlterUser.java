package ioc.ddl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AlterUser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alter_user);
    }
}