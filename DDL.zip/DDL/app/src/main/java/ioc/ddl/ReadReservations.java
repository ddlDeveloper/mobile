package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.Button;


public class ReadReservations extends AppCompatActivity {


    private Button landscape, portrait, back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_reservations);

        getSupportActionBar().hide();

        back = findViewById(R.id.back);
        portrait = findViewById(R.id.portrait);
        landscape = findViewById(R.id.lanndscape);

        portrait.setOnClickListener(v -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE));
        landscape.setOnClickListener(v -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT));
        back.setOnClickListener(v -> startActivity(new Intent(this, Reservations.class)));

    }

}