package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;


public class UpdateGuest extends AppCompatActivity {

    private boolean ok;

    private LogIn logIn = new LogIn();

    private DataOutputStream outputStream;

    private Button back, save;

    private EditText user, password, name, surname, mail,
            docType, numDoc, street, phone, gender, role;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_guest);

        getSupportActionBar().hide();

        user = findViewById(R.id.user);
        password = findViewById(R.id.password);
        name = findViewById(R.id.name);
        surname = findViewById(R.id.phone);
        mail = findViewById(R.id.mail);
        docType = findViewById(R.id.docType);
        numDoc = findViewById(R.id.numdoc);
        street = findViewById(R.id.street);
        phone = findViewById(R.id.phone);
        gender = findViewById(R.id.gender);
        role = findViewById(R.id.role);

        back = findViewById(R.id.back);
        save = findViewById(R.id.save);

        back.setOnClickListener(v -> startActivity(new Intent(this, Guests.class)));

        save.setOnClickListener(v -> {

            userCheck(
                    user.getText().toString(), password.getText().toString(),
                    name.getText().toString(), surname.getText().toString(), mail.getText().toString(),
                    docType.getText().toString(), numDoc.getText().toString(), street.getText().toString(),
                    phone.getText().toString(), gender.getText().toString(), role.getText().toString()
            );

            if (ok) {
                new Task().execute("");
                Toast.makeText(this, "SAVED", Toast.LENGTH_LONG).show();
            }

        });

    }


    class Task extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String ... strings) {

            try {

                outputStream.writeInt(2);
                outputStream.writeInt(3);
                outputStream.writeInt(1);

                Socket socket = new Socket(logIn.getIp(), logIn.getPort());

                DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());

                outputStream.writeUTF(user.getText().toString());
                outputStream.writeUTF(password.getText().toString());
                outputStream.writeUTF(name.getText().toString());
                outputStream.writeUTF(surname.getText().toString());
                outputStream.writeUTF(mail.getText().toString());
                outputStream.writeUTF(docType.getText().toString());
                outputStream.writeUTF(numDoc.getText().toString());
                outputStream.writeUTF(street.getText().toString());
                outputStream.writeUTF(phone.getText().toString());
                outputStream.writeUTF(gender.getText().toString());
                outputStream.writeUTF(role.getText().toString());

            }

            catch (IOException e) {
                e.printStackTrace();
            }

            return strings[0];

        }

    }


    public boolean userCheck(String user, String password, String name, String surname, String mail,
                             String docType, String numDoc, String street, String phone, String gender, String role) {

        if (user.isEmpty() && password.isEmpty() && name.isEmpty() && surname.isEmpty() && mail.isEmpty() && docType.isEmpty()
                && numDoc.isEmpty() && street.isEmpty() && phone.isEmpty() && gender.isEmpty() && role.isEmpty()
        ) {
            Toast.makeText(this, "FILL THE GAPS", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else if (user.isEmpty() && !password.isEmpty() && !name.isEmpty() && !surname.isEmpty() && !mail.isEmpty() && !docType.isEmpty()
                && !numDoc.isEmpty() && !street.isEmpty() && !phone.isEmpty() && !gender.isEmpty() && !role.isEmpty()
        ) {
            Toast.makeText(this, "FILL USER GAP", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else if (!user.isEmpty() && password.isEmpty() && !name.isEmpty() && !surname.isEmpty() && !mail.isEmpty() && !docType.isEmpty()
                && !numDoc.isEmpty() && !street.isEmpty() && !phone.isEmpty() && !gender.isEmpty() && !role.isEmpty()) {
            Toast.makeText(this, "FILL PASSWORD GAP", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else if (!user.isEmpty() && !password.isEmpty() && name.isEmpty() && !surname.isEmpty() && !mail.isEmpty() && !docType.isEmpty()
                && !numDoc.isEmpty() && !street.isEmpty() && !phone.isEmpty() && !gender.isEmpty() && !role.isEmpty()) {
            Toast.makeText(this, "FILL NAME GAP", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else if (!user.isEmpty() && !password.isEmpty() && !name.isEmpty() && surname.isEmpty() && !mail.isEmpty() && !docType.isEmpty()
                && !numDoc.isEmpty() && !street.isEmpty() && !phone.isEmpty() && !gender.isEmpty() && !role.isEmpty()) {
            Toast.makeText(this, "FILL SURNAME GAP", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else if (!user.isEmpty() && !password.isEmpty() && !name.isEmpty() && !surname.isEmpty() && mail.isEmpty() && !docType.isEmpty()
                && !numDoc.isEmpty() && !street.isEmpty() && !phone.isEmpty() && !gender.isEmpty() && !role.isEmpty()) {
            Toast.makeText(this, "FILL MAIL GAP", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else if (!user.isEmpty() && !password.isEmpty() && !name.isEmpty() && !surname.isEmpty() && !mail.isEmpty() && docType.isEmpty()
                && !numDoc.isEmpty() && !street.isEmpty() && !phone.isEmpty() && !gender.isEmpty() && !role.isEmpty()) {
            Toast.makeText(this, "FILL DOCTYPE GAP", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else if (!user.isEmpty() && !password.isEmpty() && !name.isEmpty() && !surname.isEmpty() && !mail.isEmpty() && !docType.isEmpty()
                && numDoc.isEmpty() && !street.isEmpty() && !phone.isEmpty() && !gender.isEmpty() && !role.isEmpty()) {
            Toast.makeText(this, "FILL NUMDOC GAP", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else if (!user.isEmpty() && !password.isEmpty() && !name.isEmpty() && !surname.isEmpty() && !mail.isEmpty() && !docType.isEmpty()
                && !numDoc.isEmpty() && street.isEmpty() && !phone.isEmpty() && !gender.isEmpty() && !role.isEmpty()) {
            Toast.makeText(this, "FILL STREET GAP", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else if (!user.isEmpty() && !password.isEmpty() && !name.isEmpty() && !surname.isEmpty() && !mail.isEmpty() && !docType.isEmpty()
                && !numDoc.isEmpty() && !street.isEmpty() && phone.isEmpty() && !gender.isEmpty() && !role.isEmpty()) {
            Toast.makeText(this, "FILL PHONE GAP", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else if (!user.isEmpty() && !password.isEmpty() && !name.isEmpty() && !surname.isEmpty() && !mail.isEmpty() && !docType.isEmpty()
                && !numDoc.isEmpty() && !street.isEmpty() && !phone.isEmpty() && gender.isEmpty() && !role.isEmpty()) {
            Toast.makeText(this, "FILL GENDER GAP", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else if (!user.isEmpty() && !password.isEmpty() && !name.isEmpty() && !surname.isEmpty() && !mail.isEmpty() && !docType.isEmpty()
                && !numDoc.isEmpty() && !street.isEmpty() && !phone.isEmpty() && !gender.isEmpty() && role.isEmpty()) {
            Toast.makeText(this, "FILL ROLE GAP", Toast.LENGTH_LONG).show();
            ok = false;
        }

        else {
            ok = true;
        }

        return ok;

    }

}