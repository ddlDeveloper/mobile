package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;


public class DeleteGuest extends AppCompatActivity {

    private static boolean ok;

    private LogIn logIn = new LogIn();

    private Button back, remove;

    private EditText phone;

    private DataOutputStream outputStream = logIn.getOutputStream();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_guest);

        getSupportActionBar().hide();


        back = findViewById(R.id.back);
        phone = findViewById(R.id.phone);
        remove = findViewById(R.id.remove);


        back.setOnClickListener(v -> startActivity(new Intent(this, Guests.class)));


        remove.setOnClickListener(v -> {

            checkGuestPhone(phone.getText().toString());

            if (ok) {
                new Task().execute("");
                Toast.makeText(this, "REMOVED", Toast.LENGTH_LONG).show();
            }

        });


    }

    class Task extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String ... strings) {

            try {

                Socket socket = new Socket(logIn.getIp(), logIn.getPort());

                outputStream = new DataOutputStream(socket.getOutputStream());

                outputStream.writeUTF(phone.getText().toString());

                outputStream.writeInt(2);
                outputStream.writeInt(2);
                outputStream.writeInt(1);



            }

            catch (IOException e) {
                e.printStackTrace();
            }

            return strings[0];

        }

    }


    public static boolean checkGuestPhone(String phone) {

        char[] phoneNumber = phone.toCharArray();

        for (int i = 0; i < phoneNumber.length; i++) {

            if (Character.isLetter(phone.charAt(i))) {
                ok = false;
                System.out.println ("COINTAINS LETTERS");
            }
        }

        if (phone.isEmpty()) {
            System.out.println ("FILL PHONE GAP");
            ok = false;
        }

        else {
            ok = true;
            System.out.println ("ok");
        }

        return ok;

    }

}