package ioc.ddl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.EditText;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ReadGuests extends AppCompatActivity {

    private LogIn logIn;
    DataOutputStream outputStream;
    DataInputStream inputStream;
    private EditText id, name, lastname, doctype, numdoc, address,
            phone, mail, access, user, password, gender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_guests);

        id = findViewById(R.id.id);
        name = findViewById(R.id.name);
        lastname = findViewById(R.id.lastname);
        doctype = findViewById(R.id.doctype);
        numdoc = findViewById(R.id.numdoc);
        address = findViewById(R.id.address);
        phone = findViewById(R.id.phone);
        mail = findViewById(R.id.mail);
        access = findViewById(R.id.access);
        user = findViewById(R.id.user);
        password = findViewById(R.id.pwd);
        gender = findViewById(R.id.gender);


    }

    class Task extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String ... strings) {

            try {

                Socket socket = new Socket(logIn.getIp(), logIn.getPort());

                outputStream = new DataOutputStream(socket.getOutputStream());
                inputStream = new DataInputStream(socket.getInputStream());

                outputStream.writeInt(7);
                outputStream.writeInt(4);
                outputStream.writeInt(1);

                outputStream.writeInt(Integer.parseInt(id.getText().toString()));
                outputStream.writeUTF(name.getText().toString());
                outputStream.writeUTF(lastname.getText().toString());
                outputStream.writeUTF(doctype.getText().toString());
                outputStream.writeUTF(numdoc.getText().toString());
                outputStream.writeUTF(address.getText().toString());
                outputStream.writeUTF(phone.getText().toString());
                outputStream.writeUTF(mail.getText().toString());
                outputStream.writeUTF(access.getText().toString());
                outputStream.writeUTF(user.getText().toString());
                outputStream.writeUTF(password.getText().toString());
                outputStream.writeUTF(gender.getText().toString());

            }

            catch (IOException e) {

                e.printStackTrace();
            }

            return strings[0];

        }



    }


}