package ioc.ddl;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.EditText;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;


public class Connect extends AsyncTask<String, Void, String> {


    private LogIn logIn;

    private int serverResponse;

    /*private EditText
            user = logIn.findViewById(R.id.user),
            password = logIn.findViewById(R.id.passwd);*/
    private String user, password;

    private static final String TAG = "Server Response: ";

    private DataInputStream dataInputStream;
    private DataOutputStream dataOutputStream;


    @Override
    protected String doInBackground(String ... strings) {

        try {

            Socket socket = new Socket(logIn.getIp(), logIn.getPort());

            dataInputStream = new DataInputStream(socket.getInputStream());
            dataOutputStream = new DataOutputStream(socket.getOutputStream());

            dataOutputStream.writeUTF(user);
            dataOutputStream.writeUTF(password);
            dataOutputStream.writeInt(1);

            serverResponse = dataInputStream.readInt();
            Log.i(TAG, "L'usuari té l'id assignat: " + serverResponse);

        }

        catch (IOException e) {
            e.printStackTrace();
        }

        return strings[0];

    }

    public void execute(EditText user, EditText passwd) {
        user = user;
        password = String.valueOf(passwd);
    }
}
