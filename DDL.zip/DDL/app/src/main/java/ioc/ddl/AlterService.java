package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;


public class AlterService extends AppCompatActivity {

    private Button back, save;

    private LogIn logIn = new LogIn();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alter_service);

        getSupportActionBar().hide();

        back = findViewById(R.id.back);
        save = findViewById(R.id.save);

        back.setOnClickListener(v -> startActivity(new Intent(this, Services.class)));




    }

    class Task extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String ... strings) {

            try {

                Socket socket = new Socket(logIn.getIp(), logIn.getPort());

                DataInputStream inputStream = new DataInputStream(socket.getInputStream());
                DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());



                outputStream.writeInt(1);

            }

            catch (IOException e) {
                e.printStackTrace();
            }

            return strings[0];

        }

    }
}