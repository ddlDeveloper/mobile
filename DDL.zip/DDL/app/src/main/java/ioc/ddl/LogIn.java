package ioc.ddl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class LogIn extends AppCompatActivity {

    private int port = 8000;
    private String ip = "10.0.2.2";
    //private String ip = "192.168.1.17";
    //private String ip = "127.0.0.1";

    public int getPort() {

        return port;
    }
    public String getIp() {

        return ip;
    }

    private DataInputStream dataInputStream;
    private DataOutputStream dataOutputStream;

    public DataInputStream getDataInputStream() {

        return dataInputStream;
    }
    public DataOutputStream getDataOutputStream() {

        return dataOutputStream;
    }

    private Button signUpBut, logIn;
    private EditText passwd, user;

    final String KEY = "abecedari69@";

    private int resposta_id;
    private int rol;

    private boolean usrValid;
    private static final String TAG = "Resposta server: ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        user = findViewById(R.id.user);
        passwd = findViewById(R.id.passwd);

        logIn = findViewById(R.id.loginBtn);
        signUpBut = findViewById(R.id.signUpBtn);

        getSupportActionBar().hide();

        signUpBut.setOnClickListener(v -> startActivity(new Intent(this, SignUp.class)));

        logIn.setOnClickListener(v -> {

            validaUsuari(user.getText().toString(), passwd.getText().toString());

            if (usrValid) {

                new Tasca().execute(user.getText().toString());


                //startActivity(new Intent(this, MainMenu.class));

            }

        });

    }

    public void connectar(View v) {
        Connect conn = new Connect();
        conn.execute();
    }

    public boolean validaUsuari(String usr, String pass) {

        if (usr.isEmpty() && pass.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Introdueix usuari i contrasenya", Toast.LENGTH_LONG).show();
            usrValid = false;

        }

        else if (usr.isEmpty()) {
            Toast.makeText(this, "Introdueix un usuari", Toast.LENGTH_SHORT).show();
            usrValid = false;

        }

        else if (pass.isEmpty()) {
            Toast.makeText(this, "Introdueix una contrasenya", Toast.LENGTH_SHORT).show();
            usrValid = false;

        }

        else {
            usrValid = true;

        }

        return usrValid;

    }


    class Tasca extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String ... strings) {

            try {

                Socket socket = new Socket(ip, port);

                dataInputStream = new DataInputStream(socket.getInputStream());
                dataOutputStream = new DataOutputStream(socket.getOutputStream());

                String resposta_server = dataInputStream.readUTF();

                dataOutputStream.writeUTF(user.getText().toString());
                String passEncriptat = Encriptar(passwd.getText().toString());
                dataOutputStream.writeUTF(passEncriptat);

                dataOutputStream.writeInt(1);

                resposta_id = dataInputStream.readInt();
                rol = dataInputStream.readInt();
                Log.i(TAG, "L'usuari té l'id assignat: " + resposta_id);


            }

            catch (IOException e) {
                e.printStackTrace();
            }

            return strings[0];

        }

        @Override
        public void onPostExecute(String s){
            if (resposta_id > 0){

               /* if (rol == 1){
                /*Intent intent = new Intent(LogIn.this, AdminMenu.class);

                intent.putExtra("usuari", user.getText());
                intent.putExtra("password", passwd.getText());
                intent.putExtra("id", String.valueOf(resposta_id));
                intent.putExtra("rol", String.valueOf(rol));*/

                //startActivity(intent);
                 /*   startActivity(new Intent(LogIn.this, MainMenu.class));
                }*/
                startActivity(new Intent(LogIn.this, AdminMenu.class));
            }
        }

    }

    // Clau d'encriptació / desencriptació
    public SecretKeySpec CrearClave(String llave) {

        try {

            byte[] cadena = llave.getBytes("UTF-8");
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            cadena = md.digest(cadena);
            cadena = Arrays.copyOf(cadena, 16);
            SecretKeySpec secretKeySpec = new SecretKeySpec(cadena, "AES");

            return secretKeySpec;

        } catch (Exception e) {

            return null;

        }

    }

    // Encriptar
    public String Encriptar(String encriptar) {

        try {

            SecretKeySpec secretKeySpec = CrearClave(KEY);
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);

            byte[] cadena = encriptar.getBytes("UTF-8");
            byte[] encriptada = cipher.doFinal(cadena);
            String encrypt = Base64.encodeToString(encriptada, Base64.DEFAULT);
            //String cadena_encriptada = new String(cadena_encriptar);
            //encriptar = new String(encriptada);

            return encrypt;

        } catch (Exception e) {

            return "";

        }
    }

}




