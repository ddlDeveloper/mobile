package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;


public class LogIn extends AppCompatActivity {

    private int port = 8000;
    private String ip = "10.0.2.2";

    public int getPort() {

        return port;
    }
    public String getIp() {

        return ip;
    }

    private DataInputStream dataInputStream;
    private DataOutputStream dataOutputStream;

    public DataInputStream getDataInputStream() {

        return dataInputStream;
    }
    public DataOutputStream getDataOutputStream() {

        return dataOutputStream;
    }

    private Button signUp, logIn;
    private EditText passwd, user;

    final String KEY = "abecedari69@";

    private int serverResponse;
    private int role;

    private boolean notEmpty;
    private static final String TAG = "Resposta server: ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        user = findViewById(R.id.user);
        passwd = findViewById(R.id.passwd);

        logIn = findViewById(R.id.login);
        signUp = findViewById(R.id.signUp);

        getSupportActionBar().hide();

        signUp.setOnClickListener(v -> startActivity(new Intent(this, Register.class)));

        logIn.setOnClickListener(v -> {

            loginNotEmpty(user.getText().toString(), passwd.getText().toString());

            if (notEmpty) {

                new Task().execute("");

                Log.i("serverResponse -> ", String.valueOf(serverResponse));
                Log.i("role -> ", String.valueOf(role));

                if (serverResponse == 0) {
                    if (role == 0) {
                        startActivity(new Intent(this, AdMenu.class));

                    }
                }
//                if (serverResponse == 0) startActivity(new Intent(this, AdminMenu.class));
//                else startActivity(new Intent(this, NoAdminMenu.class));

            }

        });

    }


    public boolean loginNotEmpty(String usr, String pass) {

        if (usr.isEmpty() && pass.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Introdueix usuari i contrassenya", Toast.LENGTH_LONG).show();
            notEmpty = false;

        }

        else if (usr.isEmpty()) {
            Toast.makeText(this, "Introdueix un usuari", Toast.LENGTH_SHORT).show();
            notEmpty = false;

        }

        else if (pass.isEmpty()) {
            Toast.makeText(this, "Introdueix una contrassenya", Toast.LENGTH_SHORT).show();
            notEmpty = false;

        }

        else {
            notEmpty = true;

        }

        return notEmpty;

    }


    class Task extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String ... strings) {

            try {

                Socket socket = new Socket(ip, port);

                dataInputStream = new DataInputStream(socket.getInputStream());
                dataOutputStream = new DataOutputStream(socket.getOutputStream());

                dataOutputStream.writeUTF(user.getText().toString());
                String passEncriptat = encode(passwd.getText().toString());
                dataOutputStream.writeUTF(passEncriptat);

                dataOutputStream.writeInt(1);

                serverResponse = dataInputStream.readInt();
                role = dataInputStream.readInt();

            }

            catch (IOException e) {
                e.printStackTrace();
            }

            return strings[0];

        }


        @Override
        public void onPostExecute(String s) {

            if (serverResponse > 0) {

                if (role == 1) {

                /*Intent intent = new Intent(LogIn.this, AdminMenu.class);

                intent.putExtra("usuari", user.getText());
                intent.putExtra("password", passwd.getText());
                intent.putExtra("id", String.valueOf(resposta_id));
                intent.putExtra("rol", String.valueOf(rol));*/
                    Toast.makeText(LogIn.this, "DBG", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(LogIn.this, MainMenu.class));

                }
                //startActivity(new Intent(LogIn.this, MainMenu.class));
            }

        }

    }


    public SecretKeySpec newKey(String llave) {

        try {

            byte[] bytes = llave.getBytes("UTF-8");
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            bytes = md.digest(bytes);
            bytes = Arrays.copyOf(bytes, 16);
            SecretKeySpec secretKeySpec = new SecretKeySpec(bytes, "AES");

            return secretKeySpec;

        }

        catch (Exception e) {

            return null;

        }

    }


    public String encode(String encriptar) {

        try {

            SecretKeySpec secretKeySpec = newKey(KEY);
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);

            byte[] bytes = encriptar.getBytes("UTF-8");
            byte[] encriptada = cipher.doFinal(bytes);
            String encrypt = Base64.encodeToString(encriptada, Base64.DEFAULT);
            //String cadena_encriptada = new String(cadena_encriptar);
            //encriptar = new String(encriptada);

            return encrypt;

        } catch (Exception e) {

            return "";

        }
    }


}




