package ioc.ddl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class AdMenu extends AppCompatActivity {

    Button reservation, discounts, services, users, logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ad_menu);

        reservation = findViewById(R.id.reservation);
        discounts = findViewById(R.id.discounts);
        services = findViewById(R.id.services);
        users = findViewById(R.id.users);
        logout = findViewById(R.id.logout);

        getSupportActionBar().hide();


        reservation.setOnClickListener(v -> startActivity(new Intent(this, Reservation.class)));


        discounts.setOnClickListener(v -> startActivity(new Intent(this, Discounts.class)));


        services.setOnClickListener(v -> startActivity(new Intent(this, Services.class)));


        users.setOnClickListener(v -> startActivity(new Intent(this, Users.class)));


        logout.setOnClickListener(v -> startActivity(new Intent(this, LogIn.class)));

    }

}