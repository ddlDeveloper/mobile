package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;


public class AdminMenu extends AppCompatActivity {

    Button reservation, services, users, logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_menu);

        getSupportActionBar().hide();

        reservation = findViewById(R.id.reservation);
        services = findViewById(R.id.services);
        users = findViewById(R.id.users);
        logout = findViewById(R.id.logout);

        reservation.setOnClickListener(v -> startActivity(new Intent(this, Reservation.class)));

        services.setOnClickListener(v -> startActivity(new Intent(this, Services.class)));

        users.setOnClickListener(v -> startActivity(new Intent(this, Users.class)));

        logout.setOnClickListener(v -> {

            startActivity(new Intent(this, LogIn.class));

        });


    }

}