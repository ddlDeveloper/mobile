package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;


public class CreateService extends AppCompatActivity {

    private Spinner spinner;

    private String[] services = {"SPA", "GYM", "THEATRE", "HAIRDRESSER", "SAUNA", "TENNIS", "BILLARDS", "TOUR"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_service);

        getSupportActionBar().hide();


        spinner = findViewById(R.id.spinner);

        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item, services);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);



    }


}