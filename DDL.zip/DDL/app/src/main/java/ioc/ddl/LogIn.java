package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import ioc.ddl.utils.SystemUtils;


public class LogIn extends AppCompatActivity {

    private int port = 8000;
    private String ip = "10.0.2.2";

    public int getPort() {

        return port;
    }
    public String getIp() {

        return ip;
    }

    private DataInputStream inputStream;
    private DataOutputStream outputStream;

    public DataInputStream getInputStream() {

        return inputStream;
    }
    public DataOutputStream getOutputStream() {

        return outputStream;
    }

    private Button signUpBut, logIn;

    private EditText passwd, user;
    public EditText getPasswd() {

        return passwd;
    }
    public EditText getUser() {

        return user;
    }

    final String KEY = "abecedari69@";

    private int rol;
    private int resposta_id;

    private boolean usrValid;
    private static final String TAG = "Resposta server: ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        user = findViewById(R.id.user);
        passwd = findViewById(R.id.passwd);

        logIn = findViewById(R.id.loginBtn);
        signUpBut = findViewById(R.id.signUpBtn);

        getSupportActionBar().hide();

        signUpBut.setOnClickListener(v -> startActivity(new Intent(this, SignUp.class)));

        logIn.setOnClickListener(v -> {

            validaUsuari(user.getText().toString(), passwd.getText().toString());

            if (usrValid) {

                new Tasca().execute("");


            }

        });

    }



    public boolean validaUsuari(String usr, String pass) {

        if (usr.isEmpty() && pass.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Introdueix usuari i contrasenya", Toast.LENGTH_LONG).show();
            usrValid = false;

        }

        else if (usr.isEmpty()) {
            Toast.makeText(this, "Introdueix un usuari", Toast.LENGTH_SHORT).show();
            usrValid = false;

        }

        else if (pass.isEmpty()) {
            Toast.makeText(this, "Introdueix una contrasenya", Toast.LENGTH_SHORT).show();
            usrValid = false;

        }

        else {
            usrValid = true;

        }

        return usrValid;

    }


    class Tasca extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String ... strings) {

            try {

                Socket socket = new Socket(ip, port);

                inputStream = new DataInputStream(socket.getInputStream());
                outputStream = new DataOutputStream(socket.getOutputStream());

                String[] claus_ps = SystemUtils.clauPublicaClient().split(",");
                outputStream.writeUTF(String.valueOf(claus_ps[0]));

                BigInteger shared_secret = SystemUtils.calculClauCompartida(inputStream.readUTF(), claus_ps[1]);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    outputStream.writeUTF(SystemUtils.encryptedText(
                                    user.getText().toString()
                                            + ","
                                            + SystemUtils.convertirSHA256(
                                            passwd.getText().toString()), shared_secret.toByteArray()
                            )

                    );

                }

                outputStream.writeInt(1);

                resposta_id = inputStream.readInt();
                rol = inputStream.readInt();
                Log.i(TAG, "L'usuari té l'id assignat: " + resposta_id);


            }

            catch (IOException e) {
                e.printStackTrace();
            }


            return strings[0];

        }

        @Override
        public void onPostExecute(String s) {

            if (resposta_id > 0) {

                startActivity(new Intent(LogIn.this, AdminMenu.class));
            }

        }

    }


    public SecretKeySpec newKey(String key) {

        try {

            byte[] bytes = key.getBytes("UTF-8");
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
            bytes = messageDigest.digest(bytes);
            bytes = Arrays.copyOf(bytes, 16);

            SecretKeySpec secretKeySpec = new SecretKeySpec(bytes, "AES");

            return secretKeySpec;

        }

        catch (Exception e) {

            return null;

        }

    }


    public String encryt(String encriptar) {

        try {

            SecretKeySpec secretKeySpec = newKey(KEY);
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);

            byte[] bytes = encriptar.getBytes("UTF-8");
            byte[] doFinal = cipher.doFinal(bytes);
            String encrypt = Base64.encodeToString(doFinal, Base64.DEFAULT);

            return encrypt;

        }

        catch (Exception e) {

            return "";

        }

    }

}





