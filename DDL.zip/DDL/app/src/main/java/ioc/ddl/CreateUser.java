package ioc.ddl;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;


public class CreateUser extends AppCompatActivity {

    private LogIn logIn = new LogIn();

    private Button back, save;

    private EditText user, password, name, surname, mail,
            docType, numDoc, street, phone, gender, role;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user);

        getSupportActionBar().hide();


        user = findViewById(R.id.user);
        password = findViewById(R.id.password);
        name = findViewById(R.id.name);
        surname = findViewById(R.id.phone);
        mail = findViewById(R.id.mail);
        docType = findViewById(R.id.docType);
        numDoc = findViewById(R.id.numdoc);
        street = findViewById(R.id.street);
        phone = findViewById(R.id.phone);
        gender = findViewById(R.id.gender);
        role = findViewById(R.id.role);

        back = findViewById(R.id.back);
        save = findViewById(R.id.save);



    }
}