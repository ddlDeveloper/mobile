package ioc.ddl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class NoAdminMenu extends AppCompatActivity {

    private Button reservations, services, logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_admin_menu);

        logout = findViewById(R.id.logout);
        services = findViewById(R.id.services);
        reservations = findViewById(R.id.reservations);

        getSupportActionBar().hide();

        services.setOnClickListener(v -> startActivity(new Intent(this, NoAdminServices.class)));

        reservations.setOnClickListener(v -> startActivity(new Intent(this, NoAdminReservations.class)));

        logout.setOnClickListener(v -> startActivity(new Intent(this, LogIn.class)));


    }
}